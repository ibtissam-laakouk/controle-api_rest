package com.example.laakouk_ibtissam_controle1.service;
import com.example.laakouk_ibtissam_controle1.entities.Produit;
import com.example.laakouk_ibtissam_controle1.repository.ProduitRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class ServiceProduit {
    @Autowired
    private ProduitRepository produitRepository;


    public Produit addProduit(Produit produit) {
        return produitRepository.save(produit);
    }


    public List<Produit> getAllProduits() {
        return produitRepository.findAll();
    }

    public Optional<Produit> getProduitById(Long id) {
        return produitRepository.findById(id);
    }

    public void deleteProduit(Long id) {
        produitRepository.deleteById(id);
    }


    public List<Produit> getProduitByNom(String nom) {
        return produitRepository.findByNomProduit(nom);
    }
}


