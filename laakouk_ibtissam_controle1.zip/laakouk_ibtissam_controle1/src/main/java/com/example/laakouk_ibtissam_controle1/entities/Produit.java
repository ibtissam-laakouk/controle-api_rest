package com.example.laakouk_ibtissam_controle1.entities;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
 public class Produit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idProduit;

    private String nomProduit;
    private Double prixProduit;
    private Integer quantite;
}
