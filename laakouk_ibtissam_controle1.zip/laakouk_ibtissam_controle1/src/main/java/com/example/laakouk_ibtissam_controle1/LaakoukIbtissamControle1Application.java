package com.example.laakouk_ibtissam_controle1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LaakoukIbtissamControle1Application {

    public static void main(String[] args) {
        SpringApplication.run(LaakoukIbtissamControle1Application.class, args);
    }

}
