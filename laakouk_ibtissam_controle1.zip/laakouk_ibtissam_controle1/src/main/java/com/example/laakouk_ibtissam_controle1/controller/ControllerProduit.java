package com.example.laakouk_ibtissam_controle1.controller;

public class ControllerProduit {
}
