package com.example.laakouk_ibtissam_controle1.repository;

import com.example.laakouk_ibtissam_controle1.entities.Produit;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
public interface ProduitRepository  extends JpaRepository<Produit, Long>
{
    List<Produit> findByNomProduit(String nomProduit);
}

